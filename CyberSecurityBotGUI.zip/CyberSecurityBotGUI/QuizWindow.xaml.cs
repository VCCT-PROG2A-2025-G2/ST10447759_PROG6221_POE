﻿// QuizWindow.xaml.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using CyberSecurityBot.Core; // <-- Import the shared engine namespace

namespace CyberSecurityBotGUI
{
    public partial class QuizWindow : Window
    {
        private readonly List<Question> questions;
        private int currentQuestionIndex = 0;
        private int selectedOptionIndex = -1;

        public QuizWindow()
        {
            InitializeComponent();
            questions = QuizBank.Questions; // Pull questions from the central bank
            DisplayQuestion();
        }

        private void DisplayQuestion()
        {
            if (currentQuestionIndex >= questions.Count)
            {
                MessageBox.Show("Quiz complete!", "Done", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
                return;
            }

            var question = questions[currentQuestionIndex];
            QuestionText.Text = question.Text;
            QuestionNumberText.Text = $"Question {currentQuestionIndex + 1} of {questions.Count}";
            QuizProgress.Value = currentQuestionIndex + 1;

            OptionsPanel.Children.Clear();
            selectedOptionIndex = -1;
            FeedbackText.Text = "";

            for (int i = 0; i < question.Options.Count; i++)
            {
                var optionButton = new RadioButton
                {
                    Content = question.Options[i],
                    GroupName = "OptionsGroup",
                    Margin = new Thickness(0, 10, 0, 0),
                    FontWeight = FontWeights.SemiBold,
                    Tag = i
                };

                optionButton.Checked += (s, e) =>
                {
                    selectedOptionIndex = (int)((RadioButton)s).Tag;
                };

                OptionsPanel.Children.Add(optionButton);
            }
        }

        private async void Submit_Click(object sender, RoutedEventArgs e)
        {
            if (selectedOptionIndex == -1)
            {
                FeedbackText.Text = "Please select an option.";
                return;
            }

            var question = questions[currentQuestionIndex];
            if (selectedOptionIndex == question.CorrectIndex)
            {
                FeedbackText.Text = "Correct!";
            }
            else
            {
                FeedbackText.Text = $"Incorrect. Correct answer: {question.Options[question.CorrectIndex]}";
            }

            currentQuestionIndex++;
            await Task.Delay(1500); // Brief delay to show feedback
            DisplayQuestion();
        }
    }
}

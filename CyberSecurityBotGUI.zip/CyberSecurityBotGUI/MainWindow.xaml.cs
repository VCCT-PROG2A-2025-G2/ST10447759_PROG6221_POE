﻿// MainWindow.xaml.cs
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using CyberSecurityBot.Core;
using CyberSecurityBotGUI; // Ensure this using directive is present

namespace CyberSecurityBot
{
    public partial class MainWindow : Window
    {
        private readonly ChatBotEngine _bot = new ChatBotEngine();
        public ObservableCollection<ChatMessage> Messages { get; } = new ObservableCollection<ChatMessage>();

        // Make _taskWindow a field to manage its instance
        private TaskWindow _taskWindow;

        public MainWindow()
        {
            InitializeComponent();

            ChatList.ItemsSource = Messages;
            ChatList.ItemTemplateSelector = new ChatTemplateSelector
            {
                UserMessageTemplate = (DataTemplate)Resources["UserMessageTemplate"],
                BotMessageTemplate = (DataTemplate)Resources["BotMessageTemplate"]
            };

            // Initialize TaskWindow for the first time when MainWindow starts
            _taskWindow = new TaskWindow();

            // Handle parsed task on startup (if any, though less common for initial launch)
            if (_bot.ParsedTask != null)
            {
                _taskWindow.AddExternalTask(_bot.ParsedTask);
                _bot.ParsedTask = null; // Clear it after adding
            }

            // Initial greeting
            Messages.Add(new ChatMessage
            {
                Text = "Welcome to the CyberSecurity Bot!",
                IsUser = false
            });
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string input = InputText.Text.Trim();
            if (string.IsNullOrEmpty(input)) return;

            Messages.Add(new ChatMessage { Text = input, IsUser = true });

            string response = _bot.GetResponse(input);

            // Check if a task was parsed by the chatbot
            if (_bot.ParsedTask != null)
            {
                EnsureTaskWindowOpen(); // Ensure _taskWindow is active or re-created
                _taskWindow.AddExternalTask(_bot.ParsedTask);
                _bot.ParsedTask = null; // Clear the parsed task after handling it
            }

            Messages.Add(new ChatMessage { Text = response, IsUser = false });
            ActivityLog.Add($"Interacted with chatbot: '{input}'");

            InputText.Text = string.Empty;
            ChatScroll.ScrollToEnd();

            // Auto-popups: Ensure TaskWindow is managed correctly here too
            if (response.Contains("Task Assistant"))
            {
                EnsureTaskWindowOpen(); // Ensure _taskWindow is active or re-created
            }

            if (response.Contains("Quiz"))
                new QuizWindow().Show(); // Quiz can always be a new instance

            if (response.Contains("Activity Log"))
                new LogWindow().Show(); // Log can always be a new instance
        }

        private void TaskBtn_Click(object sender, RoutedEventArgs e)
        {
            EnsureTaskWindowOpen(); // Ensure _taskWindow is active or re-created
        }

        // Helper method to ensure the TaskWindow is open and ready to use
        private void EnsureTaskWindowOpen()
        {
            // If the window instance is null or has been closed, create a new one.
            // A common way to check if a window is closed is by checking its IsLoaded property
            // or if the Dispatcher has shut down. If the user explicitly closes the window,
            // the existing instance becomes unusable.
            if (_taskWindow == null || !_taskWindow.IsLoaded && _taskWindow.IsVisible == false)
            {
                _taskWindow = new TaskWindow();
            }

            // Show the window if it's not visible
            if (!_taskWindow.IsVisible)
            {
                _taskWindow.Show();
            }
            // Bring the window to the foreground
            _taskWindow.Activate();
        }

        private void QuizBtn_Click(object sender, RoutedEventArgs e) => new QuizWindow().Show();
        private void LogBtn_Click(object sender, RoutedEventArgs e) => new LogWindow().Show();
    }

    public class ChatMessage
    {
        public string Text { get; set; }
        public bool IsUser { get; set; }
    }

    public class ChatTemplateSelector : DataTemplateSelector
    {
        public DataTemplate UserMessageTemplate { get; set; }
        public DataTemplate BotMessageTemplate { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var msg = item as ChatMessage;
            return msg?.IsUser == true ? UserMessageTemplate : BotMessageTemplate;
        }
    }
}
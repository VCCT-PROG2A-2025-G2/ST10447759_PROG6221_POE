﻿// App.xaml.cs
using System.Windows;

namespace CyberSecurityBotGUI
{
    public partial class App : Application
    {
        public static bool IsDarkMode = false;

    }
}
